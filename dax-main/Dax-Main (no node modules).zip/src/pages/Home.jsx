import React from 'react'
import { motion } from 'framer-motion'
import BrandCard from '../components/BrandCard'
import StatsSection from '../components/StatsSection'

const projects = [
  {
    name: "Dax the Traveler",
    link: "/dax-the-traveler",
    desc: "Epic personal adventures & chaos",
    gradient: "from-blue-400 via-cyan-400 to-green-400",
    emoji: "🧳"
  },
  {
    name: "Ani-Dax",
    link: "/ani-dax", 
    desc: "Anime bios, voiceovers, AI vids",
    gradient: "from-purple-500 via-pink-500 to-purple-600",
    emoji: "🎌"
  },
  {
    name: "Timezone Travelers",
    link: "/timezone-travelers",
    desc: "Interactive travel experiences & hacks",
    gradient: "from-orange-500 via-red-500 to-orange-600",
    emoji: "🌍"
  },
  {
    name: "God's Vessel",
    link: "/gods-vessel",
    desc: "Faith-based fashion, content, and power",
    gradient: "from-indigo-600 via-purple-600 to-indigo-700",
    emoji: "✝️"
  },
]

export default function Home() {
  // Generate floating bubble data
  const bubbles = Array.from({ length: 25 }, (_, i) => ({
    id: i,
    size: Math.random() * 8 + 4, // 4-12px
    x: Math.random() * 100, // 0-100%
    y: Math.random() * 100, // 0-100%
    delay: Math.random() * 5, // 0-5s delay
    duration: 8 + Math.random() * 12, // 8-20s duration
    opacity: 0.3 + Math.random() * 0.4, // 0.3-0.7 opacity
  }))

  const largeBubbles = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    size: 20 + Math.random() * 30, // 20-50px
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 3,
    duration: 15 + Math.random() * 10,
    rotation: Math.random() * 360,
  }))

  const microBubbles = Array.from({ length: 40 }, (_, i) => ({
    id: i,
    size: 1 + Math.random() * 2, // 1-3px
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 4 + Math.random() * 6,
  }))

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      
      {/* Floating Bubble Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {/* Regular bubbles */}
        {bubbles.map((bubble) => (
          <motion.div
            key={bubble.id}
            className="absolute rounded-full"
            style={{
              width: bubble.size,
              height: bubble.size,
              left: `${bubble.x}%`,
              top: `${bubble.y}%`,
              background: `radial-gradient(circle, 
                rgba(255, 255, 255, ${bubble.opacity}) 0%, 
                rgba(255, 255, 255, ${bubble.opacity * 0.5}) 50%, 
                rgba(255, 255, 255, 0.1) 100%)`,
              boxShadow: `
                0 0 ${bubble.size * 2}px rgba(255, 255, 255, 0.2),
                inset 0 0 ${bubble.size}px rgba(255, 255, 255, 0.1)
              `,
              backdropFilter: 'blur(1px)',
            }}
            animate={{
              y: [0, -30, -60, -30, 0],
              x: [0, 10, -5, 15, 0],
              scale: [1, 1.1, 0.9, 1.05, 1],
              opacity: [bubble.opacity, bubble.opacity * 1.2, bubble.opacity * 0.8, bubble.opacity],
            }}
            transition={{
              duration: bubble.duration,
              repeat: Infinity,
              delay: bubble.delay,
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Large iridescent bubbles */}
        {largeBubbles.map((bubble) => (
          <motion.div
            key={`large-${bubble.id}`}
            className="absolute rounded-full"
            style={{
              width: bubble.size,
              height: bubble.size,
              left: `${bubble.x}%`,
              top: `${bubble.y}%`,
              background: `conic-gradient(
                from ${bubble.rotation}deg,
                rgba(255, 255, 255, 0.3),
                rgba(147, 197, 253, 0.3),
                rgba(196, 181, 253, 0.3),
                rgba(251, 207, 232, 0.3),
                rgba(255, 255, 255, 0.3)
              )`,
              boxShadow: `
                0 0 40px rgba(255, 255, 255, 0.1),
                inset 0 0 20px rgba(255, 255, 255, 0.1)
              `,
              backdropFilter: 'blur(2px)',
            }}
            animate={{
              y: [0, -50, -100, -50, 0],
              x: [0, 20, -10, 25, 0],
              rotate: [0, 180, 360],
              scale: [1, 1.2, 0.8, 1.1, 1],
              opacity: [0.3, 0.5, 0.2, 0.4, 0.3],
            }}
            transition={{
              duration: bubble.duration,
              repeat: Infinity,
              delay: bubble.delay,
              ease: "easeInOut",
            }}
          />
        ))}

        {/* Micro sparkle bubbles */}
        {microBubbles.map((bubble) => (
          <motion.div
            key={`micro-${bubble.id}`}
            className="absolute rounded-full bg-white"
            style={{
              width: bubble.size,
              height: bubble.size,
              left: `${bubble.x}%`,
              top: `${bubble.y}%`,
              boxShadow: '0 0 4px rgba(255, 255, 255, 0.8)',
            }}
            animate={{
              y: [0, -20, -40, -20, 0],
              opacity: [0, 1, 0.5, 1, 0],
              scale: [0, 1, 1.5, 1, 0],
            }}
            transition={{
              duration: bubble.duration,
              repeat: Infinity,
              delay: bubble.delay,
              ease: "easeOut",
            }}
          />
        ))}
      </div>

      {/* Ambient background gradients */}
      <div className="fixed inset-0 pointer-events-none">
        <motion.div
          className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-br from-purple-500/5 to-pink-500/5 rounded-full blur-3xl"
          animate={{ 
            x: [0, 50, 0],
            y: [0, -30, 0],
            scale: [1, 1.2, 1]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-full blur-3xl"
          animate={{ 
            x: [0, -40, 0],
            y: [0, 20, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut", delay: 5 }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-br from-green-500/3 to-blue-500/3 rounded-full blur-3xl"
          animate={{ 
            x: [0, 30, -20, 0],
            y: [0, -25, 15, 0],
            scale: [1, 1.15, 0.9, 1]
          }}
          transition={{ duration: 30, repeat: Infinity, ease: "easeInOut", delay: 10 }}
        />
      </div>

      <div className="relative z-10 px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-20">
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-6xl md:text-8xl font-bold mb-8"
            >
              <span className="text-white">The </span>
              <span className="text-white">Dax</span>
              <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"> Collective</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl md:text-2xl text-white/90 mb-12 max-w-4xl mx-auto leading-relaxed"
            >
              Building a content empire across multiple brands. From travel adventures to anime reviews, 
              faith-based content to travel hacks - creating content that inspires and entertains.
            </motion.p>

            {/* Decorative line */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="h-px bg-gradient-to-r from-transparent via-white/30 to-transparent max-w-md mx-auto mb-16"
            />
          </div>

          {/* Stats Section */}
          <StatsSection />

          {/* Brand Cards Section */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mb-20"
          >
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="text-4xl md:text-5xl font-bold text-center mb-16 text-white"
            >
              Explore Our Brands
            </motion.h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {projects.map((project, index) => (
                <BrandCard 
                  key={index}
                  brand={project}
                  index={index}
                />
              ))}
            </div>
          </motion.div>

          {/* Call to Action Section */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.4 }}
            className="text-center"
          >
            <div className="relative">
              {/* Background glow */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-blue-500/10 rounded-3xl blur-xl"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0.5, 0.8, 0.5]
                }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              />
              
              <div className="relative bg-gray-900/20 backdrop-blur-sm rounded-3xl p-12 border border-white/10">
                <motion.h2 
                  className="text-4xl font-bold text-white mb-6"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                >
                  Ready to Join the Adventure?
                </motion.h2>
                
                <motion.p 
                  className="text-xl text-white/80 mb-8 max-w-2xl mx-auto leading-relaxed"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.6 }}
                >
                  Follow along as I build multiple brands, travel the world, and create content that matters. 
                  Subscribe to stay updated with our latest adventures and insights.
                </motion.p>
                
                <motion.button 
                  whileHover={{ 
                    scale: 1.05,
                    boxShadow: "0 20px 40px rgba(139, 92, 246, 0.3)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-4 px-10 rounded-full text-lg transition-all duration-300 shadow-lg"
                >
                  Subscribe to Updates
                </motion.button>

                {/* Floating elements around CTA */}
                <div className="absolute inset-0 pointer-events-none">
                  {[...Array(6)].map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-2 h-2 bg-white/20 rounded-full"
                      style={{
                        left: `${20 + Math.random() * 60}%`,
                        top: `${20 + Math.random() * 60}%`,
                      }}
                      animate={{
                        y: [0, -10, 0],
                        opacity: [0.2, 0.6, 0.2],
                        scale: [1, 1.2, 1]
                      }}
                      transition={{
                        duration: 3 + Math.random() * 2,
                        repeat: Infinity,
                        delay: Math.random() * 3,
                        ease: "easeInOut"
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

