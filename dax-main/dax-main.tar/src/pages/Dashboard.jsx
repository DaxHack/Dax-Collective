// src/pages/Dashboard.jsx
import React from 'react';
import AutomationDashboard from '../automation/AutomationDashboard';

const Dashboard = () => {
  return <AutomationDashboard />;
};

export default Dashboard;
