import React from 'react'
import { motion } from 'framer-motion'

const FloatingBubbles = () => {
  // Generate subtle bubble configurations
  const bubbles = Array.from({ length: 12 }, (_, i) => ({
    id: i,
    size: Math.random() * 6 + 3, // 3-9px for subtlety
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 15 + Math.random() * 10, // Slower, more atmospheric
    opacity: 0.15 + Math.random() * 0.2, // Very low opacity
  }))

  const largeBubbles = Array.from({ length: 4 }, (_, i) => ({
    id: i,
    size: 15 + Math.random() * 20, // 15-35px
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 5,
    duration: 20 + Math.random() * 15,
    opacity: 0.08 + Math.random() * 0.12, // Even more subtle
  }))

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {/* Small atmospheric bubbles */}
      {bubbles.map((bubble) => (
        <motion.div
          key={`bubble-${bubble.id}`}
          className="absolute rounded-full"
          style={{
            width: bubble.size,
            height: bubble.size,
            left: `${bubble.x}%`,
            top: `${bubble.y}%`,
            background: `radial-gradient(circle, 
              rgba(255, 255, 255, ${bubble.opacity}) 0%, 
              rgba(255, 255, 255, ${bubble.opacity * 0.3}) 70%, 
              transparent 100%)`,
            backdropFilter: 'blur(0.5px)',
          }}
          animate={{
            y: [0, -20, -40, -20, 0],
            x: [0, 5, -3, 8, 0],
            opacity: [bubble.opacity, bubble.opacity * 1.3, bubble.opacity * 0.7, bubble.opacity],
          }}
          transition={{
            duration: bubble.duration,
            repeat: Infinity,
            delay: bubble.delay,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Larger ambient bubbles */}
      {largeBubbles.map((bubble) => (
        <motion.div
          key={`large-bubble-${bubble.id}`}
          className="absolute rounded-full"
          style={{
            width: bubble.size,
            height: bubble.size,
            left: `${bubble.x}%`,
            top: `${bubble.y}%`,
            background: `radial-gradient(circle, 
              rgba(147, 197, 253, ${bubble.opacity}) 0%, 
              rgba(196, 181, 253, ${bubble.opacity * 0.5}) 50%, 
              transparent 100%)`,
            backdropFilter: 'blur(1px)',
          }}
          animate={{
            y: [0, -30, -60, -30, 0],
            x: [0, 10, -5, 12, 0],
            scale: [1, 1.1, 0.9, 1],
            opacity: [bubble.opacity, bubble.opacity * 1.4, bubble.opacity * 0.6, bubble.opacity],
          }}
          transition={{
            duration: bubble.duration,
            repeat: Infinity,
            delay: bubble.delay,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  )
}

export default FloatingBubbles

