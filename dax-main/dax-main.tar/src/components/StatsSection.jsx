import React from 'react'
import { motion } from 'framer-motion'

const StatsSection = () => {
  const stats = [
    {
      number: "4",
      label: "Active Brands",
      description: "Multi-brand content empire"
    },
    {
      number: "15+",
      label: "Countries Visited", 
      description: "Global adventures documented"
    },
    {
      number: "∞",
      label: "Adventure Infinite",
      description: "Endless content possibilities"
    },
    {
      number: "24/7",
      label: "Automation",
      description: "Always creating value"
    }
  ]

  return (
    <section className="py-20" aria-labelledby="stats-heading">
      <div className="max-w-6xl mx-auto px-4">
        <motion.h2
          id="stats-heading"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="text-3xl md:text-4xl font-bold text-center mb-16 text-white"
        >
          Our Impact
        </motion.h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                duration: 0.6, 
                delay: index * 0.1,
                ease: "easeInOut"
              }}
              whileHover={{
                scale: 1.05,
                transition: { duration: 0.2, ease: "easeInOut" }
              }}
              className="text-center group cursor-default"
            >
              <motion.div
                className="relative"
                whileHover={{
                  y: -5,
                  transition: { duration: 0.2, ease: "easeInOut" }
                }}
              >
                {/* Glow effect on hover */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  initial={{ scale: 0.8 }}
                  whileHover={{ scale: 1.1 }}
                />
                
                <div className="relative bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/50 group-hover:border-gray-600/50 transition-colors duration-300">
                  <motion.div
                    className="text-4xl md:text-5xl font-bold mb-2"
                    style={{
                      background: 'linear-gradient(135deg, #60a5fa, #a855f7, #ec4899)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      backgroundClip: 'text'
                    }}
                  >
                    {stat.number}
                  </motion.div>
                  
                  <h3 className="text-lg font-semibold text-white mb-1">
                    {stat.label}
                  </h3>
                  
                  <p className="text-sm text-gray-400 leading-relaxed">
                    {stat.description}
                  </p>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default StatsSection

